export const presets = [
    ['@babel/preset-env', {
        targets: {
            node: '14'
        }
    }]
];