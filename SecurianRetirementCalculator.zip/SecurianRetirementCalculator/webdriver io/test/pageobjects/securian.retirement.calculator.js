import Page from './page.js';

/**
 * sub page containing specific selectors and methods for a specific page
 */
class RetirementCalculator extends Page {
    /**
     * define selectors using getter methods
     */
    get manCurrentAge () {
        return $('#current-age');
    }

    async currentAge (currentAge) {
        await super.scroll(this.manCurrentAge);
        await this.manCurrentAge.setValue(currentAge);
    }

    get manRetirementAge () {
        return $('#retirement-age');
    }

    async retirementAge (retirementAge) {
        await this.manRetirementAge.setValue(retirementAge);
    }

    get manCurrentIncome () {
        return $('//div/input[@id="current-income"]');
    }

    async currentIncome (currentIncome) {
        await this.manCurrentIncome.setValue(currentIncome);
    }

    get optSpouseIncome(){
        //input#spouse-income
        return $('#spouse-income');
    }

    async spouseIncome (spouseIncome) {
        await this.optSpouseIncome.setValue(spouseIncome);
    }

    get manCurrentSavingBal(){
        //input#current-total-savings
        return $('//input[@id= "current-total-savings"]');
    }

    async currentSavingBal (currentSavingBal) {
        await this.manCurrentSavingBal.setValue(currentSavingBal);
    }

    get manAnnualSavingBal(){
        return $('#current-annual-savings');
    }
    
    async annualSavingBal (annualSavingBal) {
        await this.manAnnualSavingBal.setValue(annualSavingBal);
    }

    get manSavingsIncreaseRate(){
        return $('#savings-increase-rate');
    }

    async savingsIncreaseRate (savingsIncreaseRate) {
        // await super.scroll(this.manSavingsIncreaseRate);
        await this.manSavingsIncreaseRate.setValue(savingsIncreaseRate);
    }
    
    get manYesSocialBenefits(){
        return $('//label[@for="yes-social-benefits"]');
    }

    async yesSocialBenefits () {
        // await super.scroll(this.manYesSocialBenefits);
        await this.manYesSocialBenefits.click({ force: true });
        await this.conManMarried.waitForExist({ timeout:50000 });
    }

    get manNoSocialBenefits(){
        return $('#no-social-benefits');
    }

    async noSocialBenefits () {
        // await super.scroll(this.manNoSocialBenefits);
        await this.manNoSocialBenefits.click({ force: true });
    }

    get conManSingle(){
        return $('#single');
    }

    async single () {
        // await this.conManSingle.waitForDisplayed({ timeout:50000 });
        await this.conManSingle.click({ force: true });
    }
    
    get conManMarried(){
        return $('input#married');
    }

    async married () {
        // await super.scroll(this.conManMarried);
        await this.conManMarried.waitForDisplayed({ timeout:50000 });
        await this.conManMarried.click({ force: true });
    }

    get optSocialSecurityOverride(){
        return $('#social-security-override');
    }

    async socialSecurityOverride (socialSecurityOverride) {
        // await super.scroll(this.optSocialSecurityOverride);
        await this.optSocialSecurityOverride.setValue(socialSecurityOverride);
    }

    get defaultModal(){
        return $('//a[@data-target = "#default-values-modal"]');
    }

    async defaultModalClick () {
        await super.scroll(this.defaultModal);
        await this.defaultModal.click({ force: true });
    }

    get modalAdditionalIncome(){
        return $('#additional-income')
    }

    async additionalIncome (additionalIncome) {
        // await super.scroll(this.modalAdditionalIncome);
        await this.modalAdditionalIncome.setValue(additionalIncome);
    }

    //default value 20 years
    get modalRetirementDuration(){
        return $('#retirement-duration')
    }

    async retirementDuration (retirementDuration) {
        // await super.scroll(this.modalRetirementDuration);
        await this.modalRetirementDuration.setValue(retirementDuration);
    }

    get modalIncludeInflation(){
        return $('//input[@id="include-inflation"]')
    }

    async includeInflation () {
        // await super.scroll(this.modalIncludeInflation);
        await this.modalIncludeInflation.click({ force:true });
        await this.modalExpectedInflationRate.waitForDisplayed({ timeout:50000 });
    }

    //default value 3%
    get modalExpectedInflationRate(){
        return $('#expected-inflation-rate')
    }

    async expectedInflationRate (expectedInflationRate) {
        // await super.scroll(this.modalExpectedInflationRate);
        await this.modalExpectedInflationRate.setValue(expectedInflationRate);
    }

    get modalExcludeInflation(){
        return $('#exclude-inflation')
    }

    async excludeInflation () {
        // await super.scroll(this.modalExcludeInflation);
        await this.modalExcludeInflation.click();
    }

    //default value 75%
    get modalRetirementAnnualIncome(){
        return $('#retirement-annual-income')
    }

    async retirementAnnualIncome (retirementAnnualIncome) {
        // await super.scroll(this.modalRetirementAnnualIncome);
        await this.modalRetirementAnnualIncome.setValue(retirementAnnualIncome);
    }

    //default value 7%
    get modalPreRetirementRoi(){
        return $('#pre-retirement-roi')
    }

    async preRetirementRoi (preRetirementRoi) {
        // await super.scroll(this.modalPreRetirementRoi);
        await this.modalPreRetirementRoi.setValue(preRetirementRoi);
    }
    
    //default value 6%
    get modalPostRetirementRoi(){
        return $('#post-retirement-roi')
    }

    async postRetirementRoi (postRetirementRoi) {
        // await super.scroll(this.modalPostRetirementRoi);
        await this.modalPostRetirementRoi.setValue(postRetirementRoi);
    }

    get modalSaveChangesButton(){
        return $('//button[text()="Save changes"]')
    }

    async saveChanges () {
        // await super.scroll(this.modalPostRetirementRoi);
        await this.modalSaveChangesButton.click();
    }

    get modalCancelButton(){
        return $('#//button[text()="Cancel"]')
    }

    get calculateButton(){
        return $('//button[@data-tag-id = "submit"]')
    }
    
    get clearFormButton(){
        return $('//button[text() = "Clear form"]')
    }

    get resultDisplay(){
        return $('//h3[text()="Results"]');
    }

    async result () {
        await this.resultDisplay.waitForDisplayed({ timeout:50000 });
        let resultText = await this.resultDisplay.getText()
        return resultText;
    }

    //to hit url
    open () {
        return super.open('insights-tools/retirement-calculator.html');
    }
}

export default new RetirementCalculator();
