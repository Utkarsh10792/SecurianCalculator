// import ShadowCopy from '../pageobjects/uiChallenge1/shadowCopy.js';
// import AjaxPage from '../pageobjects/uiChallenge1/ajaxPage.js';
// import HidePage from '../pageobjects/uiChallenge1/hidePage.js';
// import ButtonColor from '../pageobjects/uiChallenge1/buttonColor.js';

import RetirementCalculator from '../pageobjects/securian.retirement.calculator.js';
import fs from 'fs';

let formData = JSON.parse(fs.readFileSync('test/testData/FormData.json'))

describe("Pre-retirement calculator",async()=>{

    formData.forEach(({CurrentAge, RetirementAge, CurrentAnnualIncome, SpouseAnnualIncome, CurrentRetirementSavings, 
        CurrentRetirementContribution, AnnualRetirementContributionIncrease, SocialSecurityIncome, RelationshipStatus, 
        SocialSecurityOverride, AdditionalOtherIncome, NumberOfYearsRetirementNeedsToLast, PostRetirementIncomeIncreaseWithInflation, 
        PostRetirementExpectedInflationRate, PercentOfFinalAnnualIncomeDesired, PreRetirementInvestmentReturn, 
        PostRetirementInvestmentReturn}) =>{
        
    it('User should be able to submit form with all required fields filled in', async () => {
        await RetirementCalculator.open()

        await RetirementCalculator.currentAge(CurrentAge);
        await RetirementCalculator.retirementAge(RetirementAge);        

        await RetirementCalculator.currentIncome(CurrentAnnualIncome);
        await RetirementCalculator.currentSavingBal(CurrentRetirementSavings);

        await RetirementCalculator.annualSavingBal(CurrentRetirementContribution);
        await RetirementCalculator.savingsIncreaseRate(AnnualRetirementContributionIncrease);

        
        await RetirementCalculator.currentSavingBal(CurrentRetirementSavings);

        if(SocialSecurityIncome == 'Yes'){
            await RetirementCalculator.yesSocialBenefits();

        } else{
            await RetirementCalculator.noSocialBenefits();
        }

        if(RelationshipStatus == 'Married'){
            await RetirementCalculator.married();
        } else{
            await RetirementCalculator.single();
        }

        await RetirementCalculator.calculateButton.click();

        
        let resultText = await RetirementCalculator.result();
        expect(resultText).toEqual('Results');
    });

    it('Additional Social Security fields should display/hide based on Social Security benefits toggle ', async () => {
        await RetirementCalculator.open();
    
        await RetirementCalculator.yesSocialBenefits();
        await expect(RetirementCalculator.conManSingle).toBeDisplayed();

        await RetirementCalculator.noSocialBenefits();
        await RetirementCalculator.conManSingle.waitForDisplayed({ reverse: true });
        await !RetirementCalculator.conManSingle.isVisible();

    });

    it('User should be able to submit form with all fields filled in', async () => {
        await RetirementCalculator.open();

        await RetirementCalculator.currentAge(CurrentAge);
        await RetirementCalculator.retirementAge(RetirementAge);        

        await RetirementCalculator.currentIncome(CurrentAnnualIncome);
        await RetirementCalculator.spouseIncome(SpouseAnnualIncome);
        await RetirementCalculator.currentSavingBal(CurrentRetirementSavings);

        await RetirementCalculator.annualSavingBal(CurrentRetirementContribution);
        await RetirementCalculator.savingsIncreaseRate(AnnualRetirementContributionIncrease);

        
        await RetirementCalculator.currentSavingBal(CurrentRetirementSavings);

        if(SocialSecurityIncome == 'Yes'){
            await RetirementCalculator.yesSocialBenefits();

        } else{
            await RetirementCalculator.noSocialBenefits();
        }

        if(RelationshipStatus == 'Married'){
            await RetirementCalculator.married();
        } else{
            await RetirementCalculator.single();
        }

        await RetirementCalculator.socialSecurityOverride(SocialSecurityOverride);
        await RetirementCalculator.calculateButton.click();

        
        let resultText = await RetirementCalculator.result();
        expect(resultText).toEqual('Results');
    });

    it('User should be able to update default calculator values', async () => {
        await RetirementCalculator.open();

        await RetirementCalculator.defaultModalClick();
        await RetirementCalculator.additionalIncome(AdditionalOtherIncome);
        await RetirementCalculator.retirementDuration(NumberOfYearsRetirementNeedsToLast);

        if(PostRetirementIncomeIncreaseWithInflation == "Yes"){
            await RetirementCalculator.includeInflation();
            await RetirementCalculator.expectedInflationRate(PostRetirementExpectedInflationRate);
        } else{
            await RetirementCalculator.excludeInflation();
        }

        await RetirementCalculator.retirementAnnualIncome(PercentOfFinalAnnualIncomeDesired);
        await RetirementCalculator.preRetirementRoi(PreRetirementInvestmentReturn);
        await RetirementCalculator.postRetirementRoi(PostRetirementInvestmentReturn);

    });


    it('Social Security income marital status check', async () => {
        await RetirementCalculator.open()

        if(SocialSecurityIncome == 'Yes'){
            await RetirementCalculator.yesSocialBenefits();

        } else{
            await RetirementCalculator.noSocialBenefits();
        }

        if(RelationshipStatus == 'Married'){
            await RetirementCalculator.married();
        } else{
            await RetirementCalculator.single();
        }
        await expect(RetirementCalculator.conManMarried).toBeChecked()
    });


});

})